export const Students = [
	{
		"studentId": "1",
		"name": "Sarah",
		"grade": "9",
		"support": "High"
	},
	{
		"studentId": "2",
		"name": "Michael",
		"grade": "9",
		"support": "High"
	},
	{
		"studentId": "3",
		"name": "Leonard",
		"grade": "11",
		"support": "Low"
	},
	{
		"studentId": "4",
		"name": "Taylor",
		"grade": "12",
		"support": "Moderate"
	},
	{
		"studentId": "5",
		"name": "Kaylee",
		"grade": "9",
		"support": "Low"
	},
	{
		"studentId": "6",
		"name": "Jennifer",
		"grade": "10",
		"support": "High"
	},
	{
		"studentId": "7",
		"name": "Lucas",
		"grade": "11",
		"support": "Moderate"
	},
	{
		"studentId": "8",
		"name": "Sean",
		"grade": "10",
		"support": "Low"
	},
	{
		"studentId": "9",
		"name": "Emily",
		"grade": "9",
		"support": "Low"
	}
]
